/***************************************************************************//**
* \file main_cm7_0.c
*   $Date: 2024-06-25 05:30:06 -0700 (Tue, 25 Jun 2024) $
*   $Revision: 330005 $
* \brief
* Main file for CM7 #0
*
********************************************************************************
* \copyright
* Copyright 2016-2019, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "cy_project.h"
#include "cy_device_headers.h"
#include "drivers/lpddr4/cy_lpddr4.h"
#include "examples/lpddr4/commonfiles/func_validation.h"
#include "examples/lpddr4/commonfiles/basic_tests.h"
#include "drivers/sysclk/cy_sysclk.h"
#include <stdio.h>
#include <stdlib.h>

#define SVN_REV_MAIN_CM7_0_C "$Revision: 330005 $"
#define SVN_DATE_MAIN_CM7_0_C "$Date: 2024-06-25 05:30:06 -0700 (Tue, 25 Jun 2024) $"

volatile bool pwrDwnRequest = false;

// define Timer-ID for cyclic MR4 reading / DQS2DQ check for retrain
#define VERTICAL_BLANKING_TIMER 0

/*************************************************************************/
#define FRAMES_PER_SECOND   60                              // videoframe rate 60 frames per second
#define VERTICAL_BLANKING_PERIOD    (1.0/FRAMES_PER_SECOND) // resulting vertical blanking period

#define TEMP_GRADIENT       30.0                            // Temperature Gradient of the System in [°C/s]
#define SYSTEM_RESP_TIME    1.0                             // System Response Time of the System in [ms]
#define TEMP_MARGIN         2                               // Temperature Matgin in [°C]
#define SENSOR_UPDATE       32                              // Sensor Update Time of the DRAM Temp Sensor Value in [ms]
#define MR4_READ_INTERVAL   ((TEMP_MARGIN-(((SENSOR_UPDATE+SYSTEM_RESP_TIME)*0.001)*TEMP_GRADIENT))/(TEMP_GRADIENT))
#ifndef CEIL
    #define CEIL(a) ( (a - (int)a)==0 ? (int)a : (int)a+1 )
#endif
#define FLOOR(a) ((double)((long)(a)- ((a)<0.0)))
#define VBLANKING_CYCLES   (MR4_READ_INTERVAL/VERTICAL_BLANKING_PERIOD)

#define MONITOR_CYCLE (CEIL((MR4_READ_INTERVAL/VERTICAL_BLANKING_PERIOD))-1)    //every (n)th vertical blanking a monitoring must be called

/******************************************************************************/
#define LED2_BLINK_TIME 2000


#if (CY_USE_PSVP == 1)
// #define USER_LED1_PORT           CY_BSP_BB_USER_LED1_PORT
// #define USER_LED1_PIN            CY_BSP_BB_USER_LED1_PIN
// #define USER_LED1_PIN_MUX        CY_BSP_BB_USER_LED1_PIN_MUX

    #define USER_BUTTON_PORT CY_BSP_BB_USER_BUTTON_1_PORT
    #define USER_BUTTON_PIN CY_BSP_BB_USER_BUTTON_1_PIN
    #define USER_BUTTON_PIN_MUX CY_BSP_BB_USER_BUTTON_1_PIN_MUX
    #define USER_BUTTON_IRQ CY_BSP_BB_USER_BUTTON_1_IRQN
#else
    #define USER_BUTTON_PORT CY_USER_BUTTON_LEFT_PORT
    #define USER_BUTTON_PIN CY_USER_BUTTON_LEFT_PIN
    #define USER_BUTTON_PIN_MUX CY_USER_BUTTON_LEFT_PIN_MUX
    #define USER_BUTTON_IRQ CY_USER_BUTTON_LEFT_IRQN

    #define USER_LED_PORT CY_USER_LED2_PORT
    #define USER_LED_PIN CY_USER_LED2_PIN
    #define USER_LED_PIN_MUX CY_USER_LED2_PIN_MUX
#endif

/*  config used GPIO Pin used for Power Down Button */
/*  as soon as button is pressed the LPDDR4 shutdown will be initiated */
const cy_stc_gpio_pin_config_t user_button_port_pin_cfg = {
    .outVal = 0ul,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = USER_BUTTON_PIN_MUX,
    .intEdge = CY_GPIO_INTR_FALLING,
    .intMask = 1ul,
    .vtrip = 0ul,
    .slewRate = 0ul,
    .driveSel = 0ul,
};

/* Setup GPIO for BUTTON1 interrupt */
const cy_stc_sysint_irq_t irq_btncfg = {
    .sysIntSrc = USER_BUTTON_IRQ,
    .intIdx = CPUIntIdx3_IRQn,
    .isEnabled = true,
};

/* Setup GPIO for LED2 */
cy_stc_gpio_pin_config_t user_led_port_pin_cfg = {
    .outVal = 0x00,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = USER_LED_PIN_MUX,
};

void ButtonIntHandler(void)
{
    uint32_t intStatus;

    /* If falling edge detected */
    intStatus = Cy_GPIO_GetInterruptStatusMasked(USER_BUTTON_PORT, USER_BUTTON_PIN);
    if (intStatus != 0ul)
    {
        Cy_GPIO_ClearInterrupt(USER_BUTTON_PORT, USER_BUTTON_PIN);
        pwrDwnRequest = true;
    }
}

/******************************************************************************/
/*                              INIT TYPE Definintion                         */
/******************************************************************************/
#define INIT_WITH_TRAINING 0
#define INIT_WITHOUT_TRAINING 1
/*
    macro to set the LPDDR4 Controller initialization
    for PSVP:
            #define INIT_TYPE       INIT_WITH_TRAINING
    for FCV or SOC both versions are possible.
    When set to #define INIT_TYPE   INIT_WITHOUT_TRAINING
    the PTSRxx register in the lpddr_config structure must be set with training
    data matching  user hardware as these values are used to load known
    training values to the phy for initialization
*/
#define INIT_TYPE INIT_WITH_TRAINING
// #define INIT_TYPE   INIT_WITHOUT_TRAINING

#if(CONFIG_TYPE == MANUAL_CONFIG)
    /** include a manual configuration */
    // #include"Config_02_RD_LLHH_WR_LLLM_1_AC2.h"
    #include "Config_02_RD_LLLH_WR_LLLM_1_AC2.h"
#elif(CONFIG_TYPE == SOL_DESIGNER_CONFIG)
    #include "soldsgncfg.h"
#endif



/** Interrupt Configuration for catching LPDDR4 Faults*/
cy_stc_sysint_irq_t irq_cfg = {
    .sysIntSrc = cpuss_interrupts_fault_0_IRQn,
    .intIdx = CPUIntIdx2_IRQn,
    .isEnabled = true};


/* exit condition for the main loop  down below*/
cy_en_lpddr4_retval_t cancelCondition = CY_LPDDR4_SUCCESS;


/*******************************************************************************
 * Fault Handler for FAULT_STRUCT0 in which the LPDDR4 faults are mapped
 * **************************************************************************//*
 *
 *  LPDDR4 faults are mapped to Fault Structure 0
 *  In this Fault Handler the actions in case of fault can be handled
 *
 ******************************************************************************/
void irqFaultReport0Handler(void)
{
    cy_en_sysflt_source_t status;

    uint32_t fltData = 0;
    status = Cy_SysFlt_GetErrorSource(FAULT_STRUCT0);

    if (status != CY_SYSFLT_NO_FAULT)
    {
        /* LPDDR4 FATAL Fault */
        if (status == CY_SYSFLT_LPDDR4_0_LPDDR4_FATAL_FAULT)
        {
            // add some usefull code for fatal handling
            fltData = Cy_SysFlt_GetData0(FAULT_STRUCT0);
            switch (fltData)
            {
            /* DATA0[0]: 0: non-correctable ECC fault */
            case 0:
                /* accord. SAS Reset at least the LPDDR4 system.
                   Reset at least the LPDDR4 system. */
                Cy_SwTmr_Stop(VERTICAL_BLANKING_TIMER);
                /* Deinitilize the LPDDR4 controller */
                Cy_Lpddr_ControllerDeInit(LPDDR40);
                /* Disable the LPDDR4 power sequencing */
                #ifdef CY_SYS_LPDDR_POWER_EN
                                Cy_SystemLpdd4PowerDown(CY_SYS_LPDDR4_PG_POLL, CY_SYS_LPDDR4_POWER_DELAY_US);
                #endif /* CY_SYS_LPDDR_POWER_EN */
                // halt System
                CY_ASSERT(0);
                break;

            /*  DATA0[0]: 1: PLL unlock fault */
            case 1:
                /*Reset at least the LPDDR4 system. */
                Cy_SwTmr_Stop(VERTICAL_BLANKING_TIMER);
                /* Deinitilize the LPDDR4 controller */
                Cy_Lpddr_ControllerDeInit(LPDDR40);
                /* Disable the LPDDR4 power sequencing */
                #ifdef CY_SYS_LPDDR_POWER_EN
                                Cy_SystemLpdd4PowerDown(CY_SYS_LPDDR4_PG_POLL, CY_SYS_LPDDR4_POWER_DELAY_US);
                #endif /* CY_SYS_LPDDR_POWER_EN */
                // halt System
                CY_ASSERT(0);
                break;
            }
            /* LPDDR4 none fatal GSM ( Global Statemachine fault */
        }
        else if (status == CY_SYSFLT_LPDDR4_0_LPDDR4_NONFATAL_GSM_FAULT)
        {
            Cy_Lpddr_SyncGSMStateOnFault();
            /*add something usefull here*/

            /* clear the interrupt flag before issuing next user command*/
            Cy_Lpddr_ClearGCFSM_DMCFG();
        }
        else if (status == CY_SYSFLT_LPDDR4_0_LPDDR4_NONFATAL_ECC_SEC_FAULT)
        {
            // add some usefull code for none fatal fault handling
            /* correctable ECC Fault */
            __NOP();
        }
        Cy_SysFlt_ClearStatus(FAULT_STRUCT0);
    }
    Cy_SysFlt_ClearInterrupt(FAULT_STRUCT0);
}


/*****************************************************************************************
 *  Example Vertical Blanking Handler could look like this.Performing 
 *  all neccessary LPDDR4 Tasks during the vertical blanking interval of the display
 * 
*****************************************************************************************/
void Cy_LPDDR4_VBlankingHandler(void)
{
    /** vbcount counts the vertical blanking periods */
    static uint8_t vbCount = MONITOR_CYCLE - 1;

    /** flag signaling that a Monitoring function was called and there might be
        a need for re-training */
    static bool posTrainPending = false;
    /** check if there might be a need for re-training */
    if(posTrainPending == true)
    {
        /** check from driver context if re-training is really needed */
        if(true == Cy_Lpddr_CheckForRetraining())
        {
            #if (CY_USE_PSVP == 1)
                /*as real re-training doesn´t work on PSVP 
                reset the retraining request manually */
                Cy_LPDDR4_PSVPFakeTraining(LPDDR40);
            #else
                #if(DQS2DQ_PVT_COMPENSATE == DQS2DQ_HW_RETRAIN)
                    /* on none PSVP HW perform the real training */
                    cancelCondition = Cy_Lpddr_RequestDQS2DQRetrain(LPDDR40);
                #elif(DQS2DQ_PVT_COMPENSATE == DQS2DQ_SW_UPDATED)
                    cancelCondition = Cy_Lpddr_ManualDQS2DQUpdate();
                #endif
            #endif
        }else
        {
            #if defined(CY_MCU_rev_a)
                Cy_LPDDR4_DLLResMCStoSta(LPDDR40);
            #endif
        }
        /** clear internal flag signaling that a re-train might be needed */
        posTrainPending=false;
    }
    else
    {
        /** increment the vertical blanking counter */
        vbCount++;
        /** if the enough vertical blanking periods elapsed trigger a
            memory monitoring function */
        if(vbCount == (MONITOR_CYCLE))
        {
            /** perform all necessary stuff for Memory Monitoring */
            Cy_Lpddr_MemoryMonitoring();
            /** set a flag indication a re-train  might be needed */
            posTrainPending=true;
            /** reset the vertical blanking counter */
            vbCount = 1;
        }
        #if defined(CY_MCU_rev_a)
        else
        {
            Cy_LPDDR4_DLLResMCStoSta(LPDDR40);
        }
        #endif
    }
}


int main(void)
{
    __enable_irq();
    SystemInit();
    #if(UART_PRINT_SHMOO == 0x1 )
        Cy_Semihosting_InitAll(CY_USB_SCB_UART_TYPE, 115200, NULL, false);
    #endif
    
    /* Enable the LPDDR4 power sequencing */
    #ifdef CY_SYS_LPDDR_POWER_EN
        Cy_SystemLpdd4PowerUp(CY_SYS_LPDDR4_PG_POLL, CY_SYS_LPDDR4_POWER_DELAY_US);
    #endif /* CY_SYS_LPDDR_POWER_EN */

    /* Init the GPIO used for the power on request button */
    Cy_GPIO_Pin_Init(USER_BUTTON_PORT, USER_BUTTON_PIN, &user_button_port_pin_cfg);

    /* Init the GPIO used to indicate end of operation */
    Cy_GPIO_Pin_Init(USER_LED_PORT, USER_LED_PIN, &user_led_port_pin_cfg);

    /***************************************************************************
                            Fault report settings
    ***************************************************************************/
    /* clear status (typically this process is done by boot code)*/
    Cy_SysFlt_ClearStatus(FAULT_STRUCT0);
    /* set the Mask bit for LPDDR fatal Fault DEC ECC Fault / PLL unlock  */
    Cy_SysFlt_SetMaskByIdx(FAULT_STRUCT0, CY_SYSFLT_LPDDR4_0_LPDDR4_FATAL_FAULT);
    /* set the Mask bit for LPDDR none fatal Global State Machine Fault */
    Cy_SysFlt_SetMaskByIdx(FAULT_STRUCT0, CY_SYSFLT_LPDDR4_0_LPDDR4_NONFATAL_GSM_FAULT);
    /* set the Mask bit for LPDDR SEC ECCC none fatal fault */
    Cy_SysFlt_SetMaskByIdx(FAULT_STRUCT0, CY_SYSFLT_LPDDR4_0_LPDDR4_NONFATAL_ECC_SEC_FAULT);
    Cy_SysFlt_SetInterruptMask(FAULT_STRUCT0);

    /***************************************************************************
                               Interrupt settings
    ***************************************************************************/
    Cy_SysInt_InitIRQ(&irq_cfg);
    Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, irqFaultReport0Handler);
    NVIC_SetPriority(irq_cfg.intIdx, 0);
    NVIC_EnableIRQ(irq_cfg.intIdx);

    Cy_SysInt_InitIRQ(&irq_btncfg);
    Cy_SysInt_SetSystemIrqVector(irq_btncfg.sysIntSrc, ButtonIntHandler);
    NVIC_SetPriority(irq_btncfg.intIdx, 3ul);
    NVIC_EnableIRQ(irq_btncfg.intIdx);

    /** Disable Cache before Cy_Lpddr_ControllerInit() when Software Aided Training is activated */
    SCB_DisableDCache();
    /* Initialize LPDDR4 with either Reload or Training */
    #if (INIT_TYPE == INIT_WITH_TRAINING)
    /* real training only possible on real silicon */
        cancelCondition = Cy_Lpddr_ControllerInit(LPDDR40, &lpddr_config, CY_LPDDR4_INIT_WITH_TRAINING);
    #elif (INIT_TYPE == INIT_WITHOUT_TRAINING)
        cancelCondition = Cy_Lpddr_ControllerInit(LPDDR40, &lpddr_config, CY_LPDDR4_INIT_WITH_RELOAD);
    #else
        #error Init Type not set
    #endif
    /** Re-enable Cache after Cy_Lpddr_ControllerInit */
    SCB_EnableDCache();
    if (cancelCondition != CY_LPDDR4_SUCCESS)
    {
        Cy_Lpddr_ControllerDeInit(LPDDR40);
        /* Disable the LPDDR4 power sequencing */
        #ifdef CY_SYS_LPDDR_POWER_EN
            Cy_SystemLpdd4PowerDown(CY_SYS_LPDDR4_PG_POLL, CY_SYS_LPDDR4_POWER_DELAY_US);
        #endif /* CY_SYS_LPDDR_POWER_EN */
        CY_ASSERT(0);
    }
    // Initializes the HW timer used as SW Timer source (SysTick)
    Cy_SwTmr_Init();

    /***/
    Cy_SwTmr_StartHighPrio(VERTICAL_BLANKING_TIMER,(uint32_t) (VERTICAL_BLANKING_PERIOD * 1000), true, Cy_LPDDR4_VBlankingHandler );
    //Main Loop starts here 
    while((cancelCondition == CY_LPDDR4_SUCCESS) && ( pwrDwnRequest == false))
    {
        /* Blink a LED after successful return */
        Cy_GPIO_Inv(USER_LED_PORT, USER_LED_PIN);
        WriteAddressToMem(0x3FFFFFFF); // Write different pattern to whole memory
    } 
    Cy_SwTmr_Stop(VERTICAL_BLANKING_TIMER);
    /* Deinitilize the LPDDR4 controller */
    Cy_Lpddr_ControllerDeInit(LPDDR40);
    /* Disable the LPDDR4 power sequencing */
    #ifdef CY_SYS_LPDDR_POWER_EN
        Cy_SystemLpdd4PowerDown(CY_SYS_LPDDR4_PG_POLL, CY_SYS_LPDDR4_POWER_DELAY_US);
    #endif /* CY_SYS_LPDDR_POWER_EN */

    while (1)
    {
        /* Blink a LED after successful return */
        Cy_SysTick_DelayInUs(2000000);
        Cy_GPIO_Inv(USER_LED_PORT, USER_LED_PIN);
    }
}

/* [] END OF FILE */
